-- Create a flags table to store uploaded flag images
CREATE TABLE flags (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  filename TEXT,
  file_type TEXT,
  file_size INTEGER,
  storage_path TEXT,
  image_url TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Enable RLS on flags
ALTER TABLE flags ENABLE ROW LEVEL SECURITY;

-- Flags policies (public read, admin write)
CREATE POLICY "flags_select" ON flags FOR SELECT TO public USING (true);
CREATE POLICY "flags_insert" ON flags FOR INSERT TO authenticated WITH CHECK (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);
CREATE POLICY "flags_update" ON flags FOR UPDATE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);
CREATE POLICY "flags_delete" ON flags FOR DELETE TO authenticated USING (
  EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND is_admin = true)
);

-- Add trigger for updated_at
CREATE TRIGGER update_flags_updated_at
  BEFORE UPDATE ON flags
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Create index for searching
CREATE INDEX idx_flags_name ON flags(name);

-- Update teams table to have a flag_id reference
ALTER TABLE teams ADD COLUMN IF NOT EXISTS flag_id UUID REFERENCES flags(id) ON DELETE SET NULL;
