-- Clear all seed/fictional data
DELETE FROM predictions;
DELETE FROM matches;
DELETE FROM teams;

-- Keep the tables but they'll be empty until admin adds data