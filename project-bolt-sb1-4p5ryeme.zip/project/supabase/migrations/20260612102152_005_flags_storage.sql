-- Create storage bucket for team flags (will be created via MCP if available)
-- This migration documents the expected setup

-- Teams table already exists, updating columns
ALTER TABLE teams DROP COLUMN IF EXISTS group_name;
