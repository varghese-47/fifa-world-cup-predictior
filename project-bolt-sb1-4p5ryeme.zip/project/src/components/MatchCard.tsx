import { useState, useEffect } from 'react';
import { Match, Prediction } from '../lib/supabase';
import { Clock, MapPin, Lock, Check, Trophy, AlertCircle, Flag as FlagIcon } from 'lucide-react';

interface MatchCardProps {
  match: Match;
  prediction?: Prediction;
  onPredict: (matchId: string, homeScore: number, awayScore: number) => Promise<void>;
  isLocked: boolean;
}

export function MatchCard({ match, prediction, onPredict, isLocked }: MatchCardProps) {
  const [homeScore, setHomeScore] = useState(prediction?.predicted_home_score ?? 0);
  const [awayScore, setAwayScore] = useState(prediction?.predicted_away_score ?? 0);
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (prediction) {
      setHomeScore(prediction.predicted_home_score);
      setAwayScore(prediction.predicted_away_score);
    }
  }, [prediction]);

  const kickoffTime = new Date(match.kickoff_time);
  const timeUntilKickoff = kickoffTime.getTime() - Date.now();
  const hoursUntil = Math.max(0, Math.floor(timeUntilKickoff / (1000 * 60 * 60)));
  const minutesUntil = Math.max(0, Math.floor((timeUntilKickoff % (1000 * 60 * 60)) / (1000 * 60)));

  const formattedDate = kickoffTime.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
  const formattedTime = kickoffTime.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
  });

  const handleSubmit = async () => {
    if (isLocked || (homeScore === prediction?.predicted_home_score && awayScore === prediction?.predicted_away_score)) {
      setEditing(false);
      return;
    }

    setSaving(true);
    await onPredict(match.id, homeScore, awayScore);
    setSaving(false);
    setEditing(false);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  const getPredictionResult = () => {
    if (!match.is_completed || !prediction) return null;
    const points = prediction.points_awarded;
    const winnerCorrect = prediction.winner_points_awarded > 0;
    const exactCorrect = prediction.exact_score_awarded;
    return { points, winnerCorrect, exactCorrect };
  };

  const predictionResult = getPredictionResult();

  const homeTeam = match.home_team;
  const awayTeam = match.away_team;

  const homeFlag = homeTeam?.flag;
  const awayFlag = awayTeam?.flag;

  return (
    <div className={`card card-hover ${isLocked ? 'opacity-75' : ''}`}>
      <div className="bg-gradient-to-r from-gray-50 to-gray-100 dark:from-gray-800 dark:to-gray-750 px-4 py-3 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="bg-grass-100 dark:bg-grass-900/30 text-grass-700 dark:text-grass-400 text-xs font-semibold px-2 py-1 rounded">
              {match.round}
            </span>
            <span className="text-xs text-gray-500 dark:text-gray-400">Match {match.match_number}</span>
          </div>
          {isLocked && (
            <div className="flex items-center gap-1 text-gray-500 dark:text-gray-400 text-xs">
              <Lock className="w-3 h-3" />
              Locked
            </div>
          )}
        </div>
      </div>

      <div className="p-4">
        <div className="flex items-center justify-between mb-4">
          {/* Home Team */}
          <div className="flex items-center gap-3 flex-1">
            {homeTeam ? (
              <>
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden shadow-md bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                  {homeFlag ? (
                    <img
                      src={homeFlag.image_url}
                      alt={homeTeam.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <FlagIcon className="w-6 h-6 text-gray-400" />
                  )}
                </div>
                <div className="min-w-0">
                  <p className="font-semibold text-gray-900 dark:text-white truncate">{homeTeam.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{homeTeam.code}</p>
                </div>
              </>
            ) : (
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                  <FlagIcon className="w-6 h-6 text-gray-400" />
                </div>
                <div>
                  <p className="font-semibold text-gray-500 dark:text-gray-400">TBD</p>
                </div>
              </div>
            )}
          </div>

          {/* Score / Prediction */}
          <div className="flex flex-col items-center px-4">
            {match.is_completed ? (
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-gray-900 dark:text-white">{match.home_score}</span>
                <span className="text-2xl text-gray-400 dark:text-gray-600">-</span>
                <span className="text-3xl font-bold text-gray-900 dark:text-white">{match.away_score}</span>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                {editing || !prediction ? (
                  <>
                    <input
                      type="number"
                      value={homeScore}
                      onChange={(e) => setHomeScore(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-14 h-14 text-center text-2xl font-bold bg-gray-100 dark:bg-gray-700 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-transparent text-gray-900 dark:text-white"
                      min="0"
                      max="15"
                      disabled={isLocked}
                    />
                    <span className="text-2xl text-gray-400 dark:text-gray-600">-</span>
                    <input
                      type="number"
                      value={awayScore}
                      onChange={(e) => setAwayScore(Math.max(0, parseInt(e.target.value) || 0))}
                      className="w-14 h-14 text-center text-2xl font-bold bg-gray-100 dark:bg-gray-700 border-2 border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-gold-500 focus:border-transparent text-gray-900 dark:text-white"
                      min="0"
                      max="15"
                      disabled={isLocked}
                    />
                  </>
                ) : (
                  <button
                    onClick={() => setEditing(true)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                      isLocked
                        ? 'cursor-not-allowed bg-gray-100 dark:bg-gray-700'
                        : 'bg-gold-100 dark:bg-gold-900/30 hover:bg-gold-200 dark:hover:bg-gold-900/50'
                    }`}
                    disabled={isLocked}
                  >
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">{prediction.predicted_home_score}</span>
                    <span className="text-2xl text-gray-400 dark:text-gray-600">-</span>
                    <span className="text-3xl font-bold text-gray-900 dark:text-white">{prediction.predicted_away_score}</span>
                  </button>
                )}
              </div>
            )}
            {!match.is_completed && (editing || !prediction) && (
              <button
                onClick={handleSubmit}
                disabled={saving || isLocked}
                className={`mt-3 flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  saved
                    ? 'bg-grass-500 text-white'
                    : 'btn-primary'
                } ${isLocked ? 'opacity-50 cursor-not-allowed' : ''}`}
              >
                {saved ? (
                  <>
                    <Check className="w-4 h-4" />
                    Saved!
                  </>
                ) : saving ? (
                  <span className="flex items-center gap-1">
                    <div className="w-3 h-3 border-2 border-gray-900 border-t-transparent rounded-full animate-spin" />
                    Saving...
                  </span>
                ) : (
                  <>
                    <Check className="w-4 h-4" />
                    {prediction ? 'Update' : 'Submit'}
                  </>
                )}
              </button>
            )}
          </div>

          {/* Away Team */}
          <div className="flex items-center gap-3 flex-1 justify-end">
            {awayTeam ? (
              <>
                <div className="min-w-0 text-right">
                  <p className="font-semibold text-gray-900 dark:text-white truncate">{awayTeam.name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{awayTeam.code}</p>
                </div>
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg overflow-hidden shadow-md bg-gray-100 dark:bg-gray-700 flex items-center justify-center">
                  {awayFlag ? (
                    <img
                      src={awayFlag.image_url}
                      alt={awayTeam.name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <FlagIcon className="w-6 h-6 text-gray-400" />
                  )}
                </div>
              </>
            ) : (
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="font-semibold text-gray-500 dark:text-gray-400">TBD</p>
                </div>
                <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-lg bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                  <FlagIcon className="w-6 h-6 text-gray-400" />
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex items-center justify-center gap-4 text-sm text-gray-500 dark:text-gray-400 border-t border-gray-100 dark:border-gray-700 pt-3">
          <div className="flex items-center gap-1">
            <Clock className="w-4 h-4" />
            {formattedDate} {formattedTime}
          </div>
          {!isLocked && hoursUntil > 0 && (
            <span className="text-grass-600 dark:text-grass-500 font-medium">
              in {hoursUntil}h {minutesUntil}m
            </span>
          )}
          {isLocked && !match.is_completed && (
            <span className="text-red-600 dark:text-red-400 font-medium">
              Kickoff passed
            </span>
          )}
        </div>

        {match.venue && (
          <div className="flex items-center justify-center gap-1 mt-2 text-sm text-gray-500 dark:text-gray-400">
            <MapPin className="w-4 h-4" />
            {match.venue}
          </div>
        )}

        {predictionResult && (
          <div className={`mt-3 p-3 rounded-lg border ${
            predictionResult.exactCorrect
              ? 'bg-gold-50 dark:bg-gold-900/20 border-gold-200 dark:border-gold-800'
              : predictionResult.winnerCorrect
              ? 'bg-grass-50 dark:bg-grass-900/20 border-grass-200 dark:border-grass-800'
              : 'bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700'
          }`}>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                {predictionResult.exactCorrect ? (
                  <>
                    <Trophy className="w-5 h-5 text-gold-500" />
                    <span className="font-semibold text-gold-700 dark:text-gold-400">Exact Score!</span>
                  </>
                ) : predictionResult.winnerCorrect ? (
                  <>
                    <Check className="w-5 h-5 text-grass-500" />
                    <span className="font-medium text-grass-700 dark:text-grass-400">Correct Winner</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-5 h-5 text-gray-400" />
                    <span className="text-gray-500 dark:text-gray-400">Incorrect</span>
                  </>
                )}
              </div>
              <div className={`text-2xl font-bold ${
                predictionResult.points > 0 ? 'text-gold-600 dark:text-gold-500' : 'text-gray-400'
              }`}>
                +{predictionResult.points} pts
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
