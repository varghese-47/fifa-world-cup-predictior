import { useAuth } from '../contexts/AuthContext';
import { Trophy, LayoutDashboard, ListOrdered, Settings, LogOut, Moon, Sun, User, Flag } from 'lucide-react';
import { useState, useEffect } from 'react';

interface HeaderProps {
  currentPage: 'matches' | 'leaderboard' | 'admin';
  onNavigate: (page: 'matches' | 'leaderboard' | 'admin') => void;
}

export function Header({ currentPage, onNavigate }: HeaderProps) {
  const { profile, signOut } = useAuth();
  const [darkMode, setDarkMode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <header className="sticky top-0 z-50 bg-white/80 dark:bg-gray-900/80 backdrop-blur-lg border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-gradient-to-br from-gold-400 to-gold-600">
              <Trophy className="w-5 h-5 text-gray-900" />
            </div>
            <div>
              <h1 className="font-bold text-gray-900 dark:text-white">WC Predictor</h1>
              <p className="text-xs text-gray-500 dark:text-gray-400 hidden sm:block">
                FIFA World Cup 2026
              </p>
            </div>
          </div>

          <nav className="hidden md:flex items-center gap-1">
            <button
              onClick={() => onNavigate('matches')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                currentPage === 'matches'
                  ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <LayoutDashboard className="w-4 h-4" />
              Matches
            </button>
            <button
              onClick={() => onNavigate('leaderboard')}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                currentPage === 'leaderboard'
                  ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <ListOrdered className="w-4 h-4" />
              Leaderboard
            </button>
            {profile?.is_admin && (
              <button
                onClick={() => onNavigate('admin')}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === 'admin'
                    ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <Settings className="w-4 h-4" />
                Admin
              </button>
            )}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="p-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            <div className="hidden sm:flex items-center gap-3 pl-3 border-l border-gray-200 dark:border-gray-700">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-grass-500 to-grass-600 flex items-center justify-center">
                  <User className="w-4 h-4 text-white" />
                </div>
                <div className="hidden lg:block">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {profile?.full_name}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {profile?.is_admin ? 'Admin' : 'Player'}
                  </p>
                </div>
              </div>
              <button
                onClick={signOut}
                className="p-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
                title="Sign out"
              >
                <LogOut className="w-5 h-5" />
              </button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
              </svg>
            </button>
          </div>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-200 dark:border-gray-800 bg-white dark:bg-gray-900 py-4">
          <nav className="flex flex-col gap-1 px-4">
            <button
              onClick={() => { onNavigate('matches'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                currentPage === 'matches'
                  ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <LayoutDashboard className="w-5 h-5" />
              Matches
            </button>
            <button
              onClick={() => { onNavigate('leaderboard'); setMobileMenuOpen(false); }}
              className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                currentPage === 'leaderboard'
                  ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                  : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
              }`}
            >
              <ListOrdered className="w-5 h-5" />
              Leaderboard
            </button>
            {profile?.is_admin && (
              <button
                onClick={() => { onNavigate('admin'); setMobileMenuOpen(false); }}
                className={`flex items-center gap-2 px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                  currentPage === 'admin'
                    ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                    : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
                }`}
              >
                <Settings className="w-5 h-5" />
                Admin
              </button>
            )}
            <div className="border-t border-gray-200 dark:border-gray-700 mt-3 pt-3">
              <div className="flex items-center gap-3 px-4 py-2">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-grass-500 to-grass-600 flex items-center justify-center">
                  <User className="w-5 h-5 text-white" />
                </div>
                <div className="flex-1">
                  <p className="font-medium text-gray-900 dark:text-white">{profile?.full_name}</p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">{profile?.email}</p>
                </div>
              </div>
              <button
                onClick={() => { signOut(); setMobileMenuOpen(false); }}
                className="w-full flex items-center gap-2 px-4 py-3 rounded-lg text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 font-medium"
              >
                <LogOut className="w-5 h-5" />
                Sign Out
              </button>
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
