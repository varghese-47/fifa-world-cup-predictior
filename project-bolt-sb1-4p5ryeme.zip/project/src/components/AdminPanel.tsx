import { useState, useEffect, useRef } from 'react';
import { supabase, Match, Team, Flag } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import {
  Settings, Plus, Edit2, Trash2, X, Users, Trophy,
  RefreshCw, AlertCircle, Check, Calendar, Clock, Flag as FlagIcon,
  Upload, Search, Image
} from 'lucide-react';

type TabType = 'flags' | 'teams' | 'matches' | 'users' | 'scoring';

interface MatchFormData {
  home_team_id: string;
  away_team_id: string;
  kickoff_time: string;
  round: string;
  venue: string;
}

const emptyMatchForm: MatchFormData = {
  home_team_id: '',
  away_team_id: '',
  kickoff_time: '',
  round: 'Group Stage',
  venue: '',
};

const BUCKEt_NAME = 'team-flags';

export function AdminPanel() {
  const { profile } = useAuth();
  const [activeTab, setActiveTab] = useState<TabType>('flags');
  const [matches, setMatches] = useState<Match[]>([]);
  const [teams, setTeams] = useState<Team[]>([]);
  const [flags, setFlags] = useState<Flag[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [message, setMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  // Match form state
  const [showMatchModal, setShowMatchModal] = useState(false);
  const [editingMatch, setEditingMatch] = useState<Match | null>(null);
  const [matchForm, setMatchForm] = useState<MatchFormData>(emptyMatchForm);

  // Team form state
  const [showTeamModal, setShowTeamModal] = useState(false);
  const [editingTeam, setEditingTeam] = useState<Team | null>(null);
  const [teamForm, setTeamForm] = useState({ name: '', code: '', flag_id: '' });
  const [teamFlagSearch, setTeamFlagSearch] = useState('');

  // Flag form state
  const [showFlagModal, setShowFlagModal] = useState(false);
  const [editingFlag, setEditingFlag] = useState<Flag | null>(null);
  const [flagForm, setFlagForm] = useState({ name: '' });
  const [flagFile, setFlagFile] = useState<File | null>(null);
  const [flagPreview, setFlagPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Flag gallery search
  const [flagSearchQuery, setFlagSearchQuery] = useState('');

  useEffect(() => {
    if (!profile?.is_admin) return;
    fetchData();
    ensureBucketExists();
  }, [profile]);

  async function ensureBucketExists() {
    const { data: buckets } = await supabase.storage.listBuckets();
    const bucketExists = buckets?.some(b => b.name === BUCKEt_NAME);

    if (!bucketExists) {
      await supabase.storage.createBucket(BUCKEt_NAME, { public: true });
    }
  }

  async function fetchData() {
    setLoading(true);
    const [matchesRes, teamsRes, flagsRes] = await Promise.all([
      supabase
        .from('matches')
        .select('*, home_team:teams!matches_home_team_id_fkey(*, flag:flags(*)), away_team:teams!matches_away_team_id_fkey(*, flag:flags(*))')
        .order('kickoff_time', { ascending: true }),
      supabase.from('teams').select('*, flag:flags(*)').order('name'),
      supabase.from('flags').select('*').order('name'),
    ]);

    if (matchesRes.data) setMatches(matchesRes.data);
    if (teamsRes.data) setTeams(teamsRes.data);
    if (flagsRes.data) setFlags(flagsRes.data);
    setLoading(false);
  }

  // === FLAG CRUD ===
  const handleFlagFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setFlagFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setFlagPreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  async function handleAddFlag() {
    if (!flagForm.name) {
      setMessage({ type: 'error', text: 'Flag name is required' });
      return;
    }

    setSaving('flag');
    setMessage(null);

    let imageUrl = editingFlag?.image_url || '';
    let storagePath = editingFlag?.storage_path || null;

    if (flagFile) {
      const fileExt = flagFile.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(7)}.${fileExt}`;
      storagePath = fileName;

      const { error: uploadError } = await supabase.storage
        .from(BUCKEt_NAME)
        .upload(fileName, flagFile, { upsert: true });

      if (uploadError) {
        setMessage({ type: 'error', text: `Upload failed: ${uploadError.message}` });
        setSaving(null);
        return;
      }

      const { data: urlData } = supabase.storage.from(BUCKEt_NAME).getPublicUrl(fileName);
      imageUrl = urlData.publicUrl;
    }

    if (!imageUrl && !editingFlag) {
      setMessage({ type: 'error', text: 'Please select a flag image' });
      setSaving(null);
      return;
    }

    if (editingFlag) {
      const { error } = await supabase
        .from('flags')
        .update({
          name: flagForm.name,
          image_url: imageUrl,
          storage_path: storagePath,
          filename: flagFile?.name || editingFlag.filename,
          file_type: flagFile?.type || editingFlag.file_type,
          file_size: flagFile?.size || editingFlag.file_size,
        })
        .eq('id', editingFlag.id);

      if (error) {
        setMessage({ type: 'error', text: error.message });
      } else {
        setMessage({ type: 'success', text: 'Flag updated successfully!' });
        setShowFlagModal(false);
        resetFlagForm();
        await fetchData();
      }
    } else {
      const { error } = await supabase.from('flags').insert({
        name: flagForm.name,
        image_url: imageUrl,
        storage_path: storagePath,
        filename: flagFile?.name,
        file_type: flagFile?.type,
        file_size: flagFile?.size,
      });

      if (error) {
        setMessage({ type: 'error', text: error.message });
      } else {
        setMessage({ type: 'success', text: 'Flag added successfully!' });
        setShowFlagModal(false);
        resetFlagForm();
        await fetchData();
      }
    }

    setSaving(null);
  }

  function resetFlagForm() {
    setEditingFlag(null);
    setFlagForm({ name: '' });
    setFlagFile(null);
    setFlagPreview(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  }

  async function handleDeleteFlag(flagId: string) {
    const flag = flags.find(f => f.id === flagId);
    if (!flag) return;

    if (!confirm(`Are you sure you want to delete "${flag.name}"? Teams using this flag will show no flag.`)) {
      return;
    }

    setSaving(flagId);

    // Delete from storage if exists
    if (flag.storage_path) {
      await supabase.storage.from(BUCKEt_NAME).remove([flag.storage_path]);
    }

    const { error } = await supabase.from('flags').delete().eq('id', flagId);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Flag deleted successfully!' });
      await fetchData();
    }
    setSaving(null);
  }

  const openEditFlag = (flag: Flag) => {
    setEditingFlag(flag);
    setFlagForm({ name: flag.name });
    setFlagPreview(flag.image_url);
    setShowFlagModal(true);
  };

  // === TEAM CRUD ===
  async function handleAddTeam() {
    if (!teamForm.name || !teamForm.code) {
      setMessage({ type: 'error', text: 'Team name and code are required' });
      return;
    }

    setSaving('team');
    setMessage(null);

    // Get flag URL if flag_id is selected
    let flagUrl = null;
    if (teamForm.flag_id) {
      const flag = flags.find(f => f.id === teamForm.flag_id);
      if (flag) flagUrl = flag.image_url;
    }

    if (editingTeam) {
      const { error } = await supabase
        .from('teams')
        .update({
          name: teamForm.name,
          code: teamForm.code.toUpperCase(),
          flag_url: flagUrl,
          flag_id: teamForm.flag_id || null,
        })
        .eq('id', editingTeam.id);

      if (error) {
        setMessage({ type: 'error', text: error.message });
      } else {
        setMessage({ type: 'success', text: 'Team updated successfully!' });
        setShowTeamModal(false);
        resetTeamForm();
        await fetchData();
      }
    } else {
      const { error } = await supabase.from('teams').insert({
        name: teamForm.name,
        code: teamForm.code.toUpperCase(),
        flag_url: flagUrl,
        flag_id: teamForm.flag_id || null,
      });

      if (error) {
        setMessage({ type: 'error', text: error.message });
      } else {
        setMessage({ type: 'success', text: 'Team added successfully!' });
        setShowTeamModal(false);
        resetTeamForm();
        await fetchData();
      }
    }
    setSaving(null);
  }

  function resetTeamForm() {
    setEditingTeam(null);
    setTeamForm({ name: '', code: '', flag_id: '' });
    setTeamFlagSearch('');
  }

  async function handleDeleteTeam(teamId: string) {
    if (!confirm('Are you sure you want to delete this team? This will also delete all matches involving this team.')) {
      return;
    }

    setSaving(teamId);
    const { error } = await supabase.from('teams').delete().eq('id', teamId);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Team deleted successfully!' });
      await fetchData();
    }
    setSaving(null);
  }

  const openEditTeam = (team: Team) => {
    setEditingTeam(team);
    setTeamForm({
      name: team.name,
      code: team.code,
      flag_id: team.flag_id || '',
    });
    setShowTeamModal(true);
  };

  // === MATCH CRUD ===
  async function handleAddMatch() {
    if (!matchForm.home_team_id || !matchForm.away_team_id || !matchForm.kickoff_time) {
      setMessage({ type: 'error', text: 'Home team, away team, and kickoff time are required' });
      return;
    }

    if (matchForm.home_team_id === matchForm.away_team_id) {
      setMessage({ type: 'error', text: 'Home and away teams must be different' });
      return;
    }

    setSaving('match');
    setMessage(null);

    const matchNumber = matches.length + 1;

    const { error } = await supabase.from('matches').insert({
      home_team_id: matchForm.home_team_id,
      away_team_id: matchForm.away_team_id,
      kickoff_time: new Date(matchForm.kickoff_time).toISOString(),
      round: matchForm.round,
      venue: matchForm.venue || null,
      match_number: matchNumber,
    });

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Match added successfully!' });
      setShowMatchModal(false);
      setMatchForm(emptyMatchForm);
      await fetchData();
    }
    setSaving(null);
  }

  async function handleUpdateMatch() {
    if (!editingMatch || !matchForm.home_team_id || !matchForm.away_team_id || !matchForm.kickoff_time) {
      setMessage({ type: 'error', text: 'All fields are required' });
      return;
    }

    if (matchForm.home_team_id === matchForm.away_team_id) {
      setMessage({ type: 'error', text: 'Home and away teams must be different' });
      return;
    }

    setSaving('match');
    setMessage(null);

    const { error } = await supabase
      .from('matches')
      .update({
        home_team_id: matchForm.home_team_id,
        away_team_id: matchForm.away_team_id,
        kickoff_time: new Date(matchForm.kickoff_time).toISOString(),
        round: matchForm.round,
        venue: matchForm.venue || null,
      })
      .eq('id', editingMatch.id);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Match updated successfully!' });
      setShowMatchModal(false);
      setEditingMatch(null);
      setMatchForm(emptyMatchForm);
      await fetchData();
    }
    setSaving(null);
  }

  async function handleDeleteMatch(matchId: string) {
    if (!confirm('Are you sure you want to delete this match? All predictions for this match will also be deleted.')) {
      return;
    }

    setSaving(matchId);
    const { error } = await supabase.from('matches').delete().eq('id', matchId);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Match deleted successfully!' });
      await fetchData();
    }
    setSaving(null);
  }

  async function handleEnterResult(matchId: string, homeScore: number, awayScore: number) {
    setSaving(matchId);
    setMessage(null);

    const { error } = await supabase
      .from('matches')
      .update({
        home_score: homeScore,
        away_score: awayScore,
        is_completed: true,
      })
      .eq('id', matchId);

    if (error) {
      setMessage({ type: 'error', text: error.message });
    } else {
      setMessage({ type: 'success', text: 'Result entered! Now calculate points.' });
      await fetchData();
    }
    setSaving(null);
  }

  async function handleCalculatePoints(matchId: string) {
    setSaving(matchId);
    setMessage(null);

    const match = matches.find((m) => m.id === matchId);
    if (!match || !match.is_completed) {
      setMessage({ type: 'error', text: 'Match must be completed first' });
      setSaving(null);
      return;
    }

    const actualHome = match.home_score!;
    const actualAway = match.away_score!;
    const actualWinner = actualHome > actualAway ? 'home' : actualHome < actualAway ? 'away' : 'draw';

    const { data: predictions } = await supabase
      .from('predictions')
      .select('*')
      .eq('match_id', matchId);

    if (!predictions || predictions.length === 0) {
      setMessage({ type: 'error', text: 'No predictions found' });
      setSaving(null);
      return;
    }

    let updated = 0;
    for (const pred of predictions) {
      const predWinner =
        pred.predicted_home_score > pred.predicted_away_score
          ? 'home'
          : pred.predicted_home_score < pred.predicted_away_score
          ? 'away'
          : 'draw';

      const winnerCorrect = predWinner === actualWinner;
      const exactCorrect = pred.predicted_home_score === actualHome && pred.predicted_away_score === actualAway;
      const points = (winnerCorrect ? 1 : 0) + (exactCorrect ? 3 : 0);

      const { error } = await supabase
        .from('predictions')
        .update({
          points_awarded: points,
          winner_points_awarded: winnerCorrect ? 1 : 0,
          exact_score_awarded: exactCorrect,
        })
        .eq('id', pred.id);

      if (!error) updated++;
    }

    setMessage({ type: 'success', text: `Points calculated for ${updated} predictions!` });
    setSaving(null);
  }

  const openEditMatch = (match: Match) => {
    setEditingMatch(match);
    setMatchForm({
      home_team_id: match.home_team_id,
      away_team_id: match.away_team_id,
      kickoff_time: new Date(match.kickoff_time).toISOString().slice(0, 16),
      round: match.round,
      venue: match.venue || '',
    });
    setShowMatchModal(true);
  };

  const filteredFlags = flags.filter(f =>
    f.name.toLowerCase().includes(flagSearchQuery.toLowerCase())
  );

  const filteredFlagsForTeams = flags.filter(f =>
    f.name.toLowerCase().includes(teamFlagSearch.toLowerCase())
  );

  if (!profile?.is_admin) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12 text-center">
        <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-4" />
        <h2 className="text-xl font-bold text-gray-900 dark:text-white mb-2">Access Denied</h2>
        <p className="text-gray-600 dark:text-gray-400">You don't have admin privileges.</p>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="w-12 h-12 border-4 border-gold-500 border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-6">
      <div className="mb-6">
        <div className="flex items-center gap-3 mb-2">
          <Settings className="w-8 h-8 text-gray-600 dark:text-gray-400" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h2>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          Manage flags, teams, matches, and scoring
        </p>
      </div>

      {message && (
        <div
          className={`mb-4 p-4 rounded-lg flex items-center gap-2 ${
            message.type === 'success'
              ? 'bg-grass-50 dark:bg-grass-900/20 text-grass-700 dark:text-grass-400 border border-grass-200 dark:border-grass-800'
              : 'bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-400 border border-red-200 dark:border-red-800'
          }`}
        >
          {message.type === 'success' ? <Check className="w-5 h-5" /> : <AlertCircle className="w-5 h-5" />}
          {message.text}
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-2 mb-6 border-b border-gray-200 dark:border-gray-700 pb-4 overflow-x-auto">
        <button
          onClick={() => setActiveTab('flags')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'flags'
              ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <FlagIcon className="w-5 h-5" />
          Flags
        </button>
        <button
          onClick={() => setActiveTab('teams')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'teams'
              ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Users className="w-5 h-5" />
          Teams
        </button>
        <button
          onClick={() => setActiveTab('matches')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'matches'
              ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <Trophy className="w-5 h-5" />
          Matches
        </button>
        <button
          onClick={() => setActiveTab('scoring')}
          className={`flex items-center gap-2 px-4 py-2 rounded-lg font-medium transition-all whitespace-nowrap ${
            activeTab === 'scoring'
              ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
              : 'text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-800'
          }`}
        >
          <RefreshCw className="w-5 h-5" />
          Scoring
        </button>
      </div>

      {/* Flags Tab */}
      {activeTab === 'flags' && (
        <div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Flag Library ({flags.length})
            </h3>
            <button
              onClick={() => {
                resetFlagForm();
                setShowFlagModal(true);
              }}
              className="btn-primary flex items-center gap-2"
            >
              <Plus className="w-5 h-5" />
              Upload Flag
            </button>
          </div>

          {/* Search */}
          {flags.length > 0 && (
            <div className="mb-4">
              <div className="relative max-w-md">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  placeholder="Search flags by name..."
                  value={flagSearchQuery}
                  onChange={(e) => setFlagSearchQuery(e.target.value)}
                  className="input-field pl-10"
                />
              </div>
            </div>
          )}

          {flags.length === 0 ? (
            <div className="card p-12 text-center">
              <Image className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400 mb-2">No flags uploaded yet</p>
              <p className="text-sm text-gray-500 dark:text-gray-500">
                Upload flag images here to use them when creating teams
              </p>
            </div>
          ) : filteredFlags.length === 0 ? (
            <div className="card p-8 text-center">
              <p className="text-gray-600 dark:text-gray-400">No flags match your search</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {filteredFlags.map((flag) => (
                <div key={flag.id} className="card p-4 group">
                  <div className="aspect-[4/3] bg-gray-100 dark:bg-gray-700 rounded-lg mb-3 overflow-hidden flex items-center justify-center">
                    <img
                      src={flag.image_url}
                      alt={flag.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <p className="font-medium text-gray-900 dark:text-white text-sm truncate mb-2">
                    {flag.name}
                  </p>
                  <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => openEditFlag(flag)}
                      className="flex-1 flex items-center justify-center gap-1 px-2 py-1 text-xs bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 rounded hover:bg-gray-200 dark:hover:bg-gray-600"
                    >
                      <Edit2 className="w-3 h-3" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDeleteFlag(flag.id)}
                      disabled={saving === flag.id}
                      className="flex-1 flex items-center justify-center gap-1 px-2 py-1 text-xs bg-red-100 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded hover:bg-red-200 dark:hover:bg-red-900/50"
                    >
                      <Trash2 className="w-3 h-3" />
                      Delete
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Teams Tab */}
      {activeTab === 'teams' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Teams ({teams.length})
            </h3>
            <button
              onClick={() => {
                resetTeamForm();
                setShowTeamModal(true);
              }}
              className="btn-primary flex items-center gap-2"
              disabled={flags.length === 0}
            >
              <Plus className="w-5 h-5" />
              Add Team
            </button>
          </div>

          {flags.length === 0 && (
            <div className="card p-4 mb-4 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
              <p className="text-yellow-700 dark:text-yellow-400 text-sm">
                Please upload flags first before creating teams.
              </p>
            </div>
          )}

          {teams.length === 0 ? (
            <div className="card p-12 text-center">
              <Users className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400 mb-2">No teams added yet</p>
              <p className="text-sm text-gray-500 dark:text-gray-500">
                Create teams from the flags you've uploaded
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {teams.map((team) => (
                <div key={team.id} className="card p-4 flex items-center gap-4">
                  {team.flag ? (
                    <img
                      src={team.flag.image_url}
                      alt={team.name}
                      className="w-14 h-12 rounded object-cover shadow"
                    />
                  ) : (
                    <div className="w-14 h-12 rounded bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
                      <FlagIcon className="w-6 h-6 text-gray-400" />
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 dark:text-white truncate">
                      {team.name}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-400">{team.code}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => openEditTeam(team)}
                      className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => handleDeleteTeam(team.id)}
                      disabled={saving === team.id}
                      className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Matches Tab */}
      {activeTab === 'matches' && (
        <div>
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Matches ({matches.length})
            </h3>
            <button
              onClick={() => {
                setEditingMatch(null);
                setMatchForm(emptyMatchForm);
                setShowMatchModal(true);
              }}
              className="btn-primary flex items-center gap-2"
              disabled={teams.length < 2}
            >
              <Plus className="w-5 h-5" />
              Add Match
            </button>
          </div>

          {teams.length < 2 && (
            <div className="card p-4 mb-4 bg-yellow-50 dark:bg-yellow-900/20 border-yellow-200 dark:border-yellow-800">
              <p className="text-yellow-700 dark:text-yellow-400 text-sm">
                You need at least 2 teams before you can create matches.
              </p>
            </div>
          )}

          {matches.length === 0 ? (
            <div className="card p-12 text-center">
              <Trophy className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
              <p className="text-gray-600 dark:text-gray-400 mb-2">No matches scheduled</p>
              <p className="text-sm text-gray-500 dark:text-gray-500">
                Create teams first, then schedule matches
              </p>
            </div>
          ) : (
            <div className="card overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 dark:bg-gray-800">
                    <tr>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                        Match
                      </th>
                      <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                        Date & Time
                      </th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                        Status
                      </th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                        Result
                      </th>
                      <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                    {matches.map((match) => (
                      <MatchRow
                        key={match.id}
                        match={match}
                        saving={saving}
                        onEdit={openEditMatch}
                        onDelete={handleDeleteMatch}
                        onEnterResult={handleEnterResult}
                      />
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Scoring Tab */}
      {activeTab === 'scoring' && (
        <div className="card p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">
            Calculate Points
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            Enter results and calculate points for completed matches.
          </p>

          {matches.filter((m) => m.is_completed).length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              No completed matches yet
            </div>
          ) : (
            <div className="space-y-3">
              {matches
                .filter((m) => m.is_completed)
                .map((match) => (
                  <div
                    key={match.id}
                    className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div>
                      <p className="font-medium text-gray-900 dark:text-white">
                        {match.home_team?.name} {match.home_score} - {match.away_score} {match.away_team?.name}
                      </p>
                      <p className="text-sm text-gray-500 dark:text-gray-400">
                        {match.round}
                      </p>
                    </div>
                    <button
                      onClick={() => handleCalculatePoints(match.id)}
                      disabled={saving === match.id}
                      className="btn-primary px-4 py-2"
                    >
                      {saving === match.id ? (
                        <span className="flex items-center gap-2">
                          <div className="w-4 h-4 border-2 border-gray-900 border-t-transparent rounded-full animate-spin" />
                          Calculating...
                        </span>
                      ) : (
                        <>
                          <RefreshCw className="w-4 h-4 mr-2" />
                          Calculate Points
                        </>
                      )}
                    </button>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* Flag Modal */}
      {showFlagModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="card max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {editingFlag ? 'Edit Flag' : 'Upload Flag'}
              </h3>
              <button
                onClick={() => { setShowFlagModal(false); resetFlagForm(); }}
                className="p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Country/Team Name
                </label>
                <input
                  type="text"
                  value={flagForm.name}
                  onChange={(e) => setFlagForm({ ...flagForm, name: e.target.value })}
                  placeholder="e.g., Canada, Brazil, Germany"
                  className="input-field"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Flag Image (PNG, JPG, SVG, WebP)
                </label>
                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                  {flagPreview ? (
                    <div className="mb-4">
                      <img
                        src={flagPreview}
                        alt="Preview"
                        className="w-24 h-16 object-cover rounded mx-auto shadow"
                      />
                    </div>
                  ) : null}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/png,image/jpeg,image/svg+xml,image/webp"
                    onChange={handleFlagFileChange}
                    className="hidden"
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="btn-secondary inline-flex items-center gap-2"
                  >
                    <Upload className="w-4 h-4" />
                    {flagPreview ? 'Change Image' : 'Select Image'}
                  </button>
                  {flagFile && (
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                      {flagFile.name} ({(flagFile.size / 1024).toFixed(1)} KB)
                    </p>
                  )}
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => { setShowFlagModal(false); resetFlagForm(); }}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddFlag}
                  disabled={saving === 'flag'}
                  className="btn-primary flex-1"
                >
                  {saving === 'flag' ? 'Saving...' : editingFlag ? 'Update' : 'Upload'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Team Modal */}
      {showTeamModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="card max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {editingTeam ? 'Edit Team' : 'Add Team'}
              </h3>
              <button
                onClick={() => { setShowTeamModal(false); resetTeamForm(); }}
                className="p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Team Name
                </label>
                <input
                  type="text"
                  value={teamForm.name}
                  onChange={(e) => setTeamForm({ ...teamForm, name: e.target.value })}
                  placeholder="e.g., Canada"
                  className="input-field"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Country Code (3 letters)
                </label>
                <input
                  type="text"
                  value={teamForm.code}
                  onChange={(e) => setTeamForm({ ...teamForm, code: e.target.value.toUpperCase() })}
                  placeholder="e.g., CAN"
                  maxLength={3}
                  className="input-field uppercase"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Flag Image
                </label>
                <input
                  type="text"
                  placeholder="Search flags..."
                  value={teamFlagSearch}
                  onChange={(e) => setTeamFlagSearch(e.target.value)}
                  className="input-field mb-2"
                />
                <div className="grid grid-cols-4 gap-2 max-h-40 overflow-y-auto p-2 bg-gray-50 dark:bg-gray-800 rounded-lg">
                  {filteredFlagsForTeams.map((flag) => (
                    <button
                      key={flag.id}
                      type="button"
                      onClick={() => setTeamForm({ ...teamForm, flag_id: flag.id })}
                      className={`aspect-[4/3] rounded overflow-hidden border-2 transition-all ${
                        teamForm.flag_id === flag.id
                          ? 'border-gold-500 ring-2 ring-gold-200'
                          : 'border-transparent hover:border-gray-300 dark:hover:border-gray-600'
                      }`}
                    >
                      <img src={flag.image_url} alt={flag.name} className="w-full h-full object-cover" />
                    </button>
                  ))}
                </div>
                {teamForm.flag_id && (
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    Selected: {flags.find(f => f.id === teamForm.flag_id)?.name}
                  </p>
                )}
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => { setShowTeamModal(false); resetTeamForm(); }}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  onClick={handleAddTeam}
                  disabled={saving === 'team'}
                  className="btn-primary flex-1"
                >
                  {saving === 'team' ? 'Saving...' : editingTeam ? 'Update' : 'Add Team'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Match Modal */}
      {showMatchModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="card max-w-md w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                {editingMatch ? 'Edit Match' : 'Add Match'}
              </h3>
              <button
                onClick={() => { setShowMatchModal(false); setEditingMatch(null); }}
                className="p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Home Team
                </label>
                <select
                  value={matchForm.home_team_id}
                  onChange={(e) => setMatchForm({ ...matchForm, home_team_id: e.target.value })}
                  className="input-field"
                >
                  <option value="">Select team...</option>
                  {teams.map((team) => (
                    <option key={team.id} value={team.id} disabled={team.id === matchForm.away_team_id}>
                      {team.name} ({team.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Away Team
                </label>
                <select
                  value={matchForm.away_team_id}
                  onChange={(e) => setMatchForm({ ...matchForm, away_team_id: e.target.value })}
                  className="input-field"
                >
                  <option value="">Select team...</option>
                  {teams.map((team) => (
                    <option key={team.id} value={team.id} disabled={team.id === matchForm.home_team_id}>
                      {team.name} ({team.code})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Kickoff Date & Time
                </label>
                <input
                  type="datetime-local"
                  value={matchForm.kickoff_time}
                  onChange={(e) => setMatchForm({ ...matchForm, kickoff_time: e.target.value })}
                  className="input-field"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Round / Stage
                </label>
                <select
                  value={matchForm.round}
                  onChange={(e) => setMatchForm({ ...matchForm, round: e.target.value })}
                  className="input-field"
                >
                  <option value="Group Stage">Group Stage</option>
                  <option value="Round of 16">Round of 16</option>
                  <option value="Quarter Finals">Quarter Finals</option>
                  <option value="Semi Finals">Semi Finals</option>
                  <option value="Final">Final</option>
                  <option value="Third Place">Third Place</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                  Venue (optional)
                </label>
                <input
                  type="text"
                  value={matchForm.venue}
                  onChange={(e) => setMatchForm({ ...matchForm, venue: e.target.value })}
                  placeholder="e.g., Wembley Stadium"
                  className="input-field"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => { setShowMatchModal(false); setEditingMatch(null); }}
                  className="btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button
                  onClick={editingMatch ? handleUpdateMatch : handleAddMatch}
                  disabled={saving === 'match'}
                  className="btn-primary flex-1"
                >
                  {saving === 'match' ? 'Saving...' : editingMatch ? 'Update' : 'Add Match'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function MatchRow({
  match,
  saving,
  onEdit,
  onDelete,
  onEnterResult,
}: {
  match: Match;
  saving: string | null;
  onEdit: (match: Match) => void;
  onDelete: (matchId: string) => void;
  onEnterResult: (matchId: string, home: number, away: number) => void;
}) {
  const [homeScore, setHomeScore] = useState(0);
  const [awayScore, setAwayScore] = useState(0);
  const [showResultInput, setShowResultInput] = useState(false);

  const kickoff = new Date(match.kickoff_time);
  const isLocked = kickoff <= new Date();

  const homeTeam = match.home_team;
  const awayTeam = match.away_team;

  return (
    <tr className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
      <td className="px-4 py-4">
        <div className="flex items-center gap-3">
          {homeTeam?.flag ? (
            <img
              src={homeTeam.flag.image_url}
              alt={homeTeam.name}
              className="w-8 h-6 rounded object-cover"
            />
          ) : (
            <div className="w-8 h-6 rounded bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
              <FlagIcon className="w-4 h-4 text-gray-400" />
            </div>
          )}
          <span className="text-sm font-medium text-gray-900 dark:text-white">
            {homeTeam?.code || 'TBD'}
          </span>
          <span className="text-gray-400">vs</span>
          <span className="text-sm font-medium text-gray-900 dark:text-white">
            {awayTeam?.code || 'TBD'}
          </span>
          {awayTeam?.flag ? (
            <img
              src={awayTeam.flag.image_url}
              alt={awayTeam.name}
              className="w-8 h-6 rounded object-cover"
            />
          ) : (
            <div className="w-8 h-6 rounded bg-gray-200 dark:bg-gray-700 flex items-center justify-center">
              <FlagIcon className="w-4 h-4 text-gray-400" />
            </div>
          )}
        </div>
        <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">{match.round}</p>
      </td>
      <td className="px-4 py-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-gray-400" />
          <div>
            <div className="text-sm text-gray-900 dark:text-white">
              {kickoff.toLocaleDateString()}
            </div>
            <div className="flex items-center gap-1 text-xs text-gray-500 dark:text-gray-400">
              <Clock className="w-3 h-3" />
              {kickoff.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </div>
          </div>
        </div>
      </td>
      <td className="px-4 py-4 text-center">
        {!match.is_completed ? (
          <span
            className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${
              isLocked
                ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                : 'bg-grass-100 dark:bg-grass-900/30 text-grass-700 dark:text-grass-400'
            }`}
          >
            {isLocked ? 'Locked' : 'Open'}
          </span>
        ) : (
          <span className="inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300">
            Completed
          </span>
        )}
      </td>
      <td className="px-4 py-4">
        {match.is_completed ? (
          <div className="text-center">
            <span className="text-lg font-bold text-gray-900 dark:text-white">
              {match.home_score} - {match.away_score}
            </span>
          </div>
        ) : showResultInput ? (
          <div className="flex items-center justify-center gap-2">
            <input
              type="number"
              value={homeScore}
              onChange={(e) => setHomeScore(parseInt(e.target.value) || 0)}
              className="w-14 h-10 text-center bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              min="0"
              max="20"
            />
            <span className="text-gray-400">-</span>
            <input
              type="number"
              value={awayScore}
              onChange={(e) => setAwayScore(parseInt(e.target.value) || 0)}
              className="w-14 h-10 text-center bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg text-gray-900 dark:text-white"
              min="0"
              max="20"
            />
            <button
              onClick={() => {
                onEnterResult(match.id, homeScore, awayScore);
                setShowResultInput(false);
              }}
              className="p-2 text-grass-600 dark:text-grass-400 hover:bg-grass-50 dark:hover:bg-grass-900/20 rounded-lg"
            >
              <Check className="w-5 h-5" />
            </button>
            <button
              onClick={() => setShowResultInput(false)}
              className="p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        ) : (
          <div className="text-center">
            <button
              onClick={() => setShowResultInput(true)}
              className="text-sm text-gold-600 dark:text-gold-400 hover:underline"
            >
              Enter Result
            </button>
          </div>
        )}
      </td>
      <td className="px-4 py-4">
        <div className="flex items-center justify-center gap-2">
          <button
            onClick={() => onEdit(match)}
            disabled={saving === match.id}
            className="p-2 text-gray-600 dark:text-gray-400 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg"
            title="Edit match"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(match.id)}
            disabled={saving === match.id}
            className="p-2 text-red-600 dark:text-red-400 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg"
            title="Delete match"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </td>
    </tr>
  );
}

function UsersPanel() {
  const [users, setUsers] = useState<Array<{ id: string; full_name: string; email: string; is_admin: boolean }>>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchUsers();
  }, []);

  async function fetchUsers() {
    const { data } = await supabase.from('profiles').select('*').order('created_at');
    if (data) setUsers(data);
    setLoading(false);
  }

  async function toggleAdmin(userId: string, currentAdmin: boolean) {
    await supabase.from('profiles').update({ is_admin: !currentAdmin }).eq('id', userId);
    fetchUsers();
  }

  if (loading) return <div className="text-center py-8">Loading users...</div>;

  return (
    <div className="card overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-50 dark:bg-gray-800">
          <tr>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Name
            </th>
            <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Email
            </th>
            <th className="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase">
              Admin
            </th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
          {users.map((user) => (
            <tr key={user.id} className="hover:bg-gray-50 dark:hover:bg-gray-800/50">
              <td className="px-4 py-3 text-gray-900 dark:text-white">{user.full_name}</td>
              <td className="px-4 py-3 text-gray-600 dark:text-gray-400">{user.email}</td>
              <td className="px-4 py-3 text-center">
                <button
                  onClick={() => toggleAdmin(user.id, user.is_admin)}
                  className={`px-3 py-1 rounded text-sm font-medium ${
                    user.is_admin
                      ? 'bg-gold-100 dark:bg-gold-900/30 text-gold-700 dark:text-gold-400'
                      : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400'
                  }`}
                >
                  {user.is_admin ? 'Admin' : 'User'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
