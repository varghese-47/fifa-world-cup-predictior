import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { Trophy, Medal, Crown, Star, Target, User, TrendingUp } from 'lucide-react';

interface LeaderboardEntry {
  user_id: string;
  full_name: string;
  total_points: number;
  correct_winners: number;
  exact_scores: number;
  rank: number;
}

export function LeaderboardPage() {
  const { user, profile } = useAuth();
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [currentRank, setCurrentRank] = useState<number | null>(null);

  useEffect(() => {
    fetchLeaderboard();
  }, [user]);

  async function fetchLeaderboard() {
    if (!user) return;

    const { data: predictions } = await supabase
      .from('predictions')
      .select('user_id, points_awarded, winner_points_awarded, exact_score_awarded');

    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, full_name');

    if (!profiles || profiles.length === 0) {
      setLoading(false);
      return;
    }

    const userStats = new Map<string, { points: number; winners: number; exact: number; name: string }>();

    profiles.forEach((p) => {
      userStats.set(p.id, { points: 0, winners: 0, exact: 0, name: p.full_name });
    });

    if (predictions) {
      predictions.forEach((pred) => {
        const stats = userStats.get(pred.user_id);
        if (stats) {
          stats.points += pred.points_awarded || 0;
          if (pred.winner_points_awarded > 0) stats.winners += 1;
          if (pred.exact_score_awarded) stats.exact += 1;
        }
      });
    }

    const sorted = Array.from(userStats.entries())
      .map(([user_id, stats]) => ({
        user_id,
        full_name: stats.name,
        total_points: stats.points,
        correct_winners: stats.winners,
        exact_scores: stats.exact,
      }))
      .sort((a, b) => {
        if (b.total_points !== a.total_points) return b.total_points - a.total_points;
        if (b.exact_scores !== a.exact_scores) return b.exact_scores - a.exact_scores;
        return b.correct_winners - a.correct_winners;
      })
      .map((entry, index) => ({ ...entry, rank: index + 1 }));

    setLeaderboard(sorted);
    const userRank = sorted.find((e) => e.user_id === user?.id)?.rank;
    setCurrentRank(userRank || null);
    setLoading(false);
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading leaderboard...</p>
        </div>
      </div>
    );
  }

  if (leaderboard.length === 0) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-6">
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            Global Leaderboard
          </h2>
        </div>
        <div className="card p-12 text-center">
          <div className="w-20 h-20 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mx-auto mb-6">
            <Trophy className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
            No Players Yet
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-2 max-w-md mx-auto">
            The leaderboard will populate once predictions are made.
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500">
            Be the first to make predictions!
          </p>
        </div>
      </div>
    );
  }

  const top3 = leaderboard.slice(0, 3);
  const rest = leaderboard.slice(3);
  const userEntry = leaderboard.find((e) => e.user_id === user?.id);

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Global Leaderboard
        </h2>
        {currentRank && (
          <div className="inline-flex items-center gap-2 bg-gold-100 dark:bg-gold-900/30 px-4 py-2 rounded-full">
            <Trophy className="w-5 h-5 text-gold-600 dark:text-gold-400" />
            <span className="text-gold-700 dark:text-gold-400 font-semibold">
              Your rank: #{currentRank}
            </span>
          </div>
        )}
      </div>

      {top3.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          {top3.map((entry, idx) => (
            <div
              key={entry.user_id}
              className={`card p-6 text-center relative ${
                entry.user_id === user?.id
                  ? 'ring-2 ring-gold-500 ring-offset-2 ring-offset-white dark:ring-offset-gray-900'
                  : ''
              } ${
                idx === 0
                  ? 'sm:order-2 bg-gradient-to-br from-gold-50 to-gold-100 dark:from-gold-900/20 dark:to-gold-900/30'
                  : idx === 1
                  ? 'sm:order-1 bg-gradient-to-br from-gray-100 to-gray-200 dark:from-gray-800 dark:to-gray-750'
                  : 'sm:order-3 bg-gradient-to-br from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-900/30'
              }`}
            >
              {idx === 0 && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center shadow-lg">
                    <Crown className="w-5 h-5 text-gray-900" />
                  </div>
                </div>
              )}
              <div className="mt-4">
                <div className={`inline-flex items-center justify-center w-16 h-16 rounded-full mb-3 ${
                  idx === 0
                    ? 'bg-gradient-to-br from-gold-400 to-gold-600'
                    : idx === 1
                    ? 'bg-gradient-to-br from-gray-400 to-gray-500'
                    : 'bg-gradient-to-br from-amber-600 to-amber-700'
                }`}>
                  <span className={`text-2xl font-bold ${idx === 0 ? 'text-gray-900' : 'text-white'}`}>
                    {entry.rank}
                  </span>
                </div>
                <h3 className="font-semibold text-gray-900 dark:text-white text-lg truncate px-2">
                  {entry.full_name}
                </h3>
                {entry.user_id === user?.id && (
                  <span className="inline-block bg-gold-200 dark:bg-gold-800 text-gold-800 dark:text-gold-200 text-xs px-2 py-0.5 rounded mt-1">
                    You
                  </span>
                )}
                <div className="mt-4 space-y-2">
                  <div className={`text-3xl font-bold ${
                    idx === 0 ? 'text-gold-600 dark:text-gold-400' : 'text-gray-700 dark:text-gray-300'
                  }`}>
                    {entry.total_points} pts
                  </div>
                  <div className="flex items-center justify-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                    <div className="flex items-center gap-1">
                      <Target className="w-4 h-4" />
                      {entry.correct_winners}
                    </div>
                    <div className="flex items-center gap-1">
                      <Star className="w-4 h-4" />
                      {entry.exact_scores}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {userEntry && userEntry.rank > 3 && (
        <div className="card mb-4 p-4 bg-gradient-to-r from-gold-50 to-gold-100 dark:from-gold-900/20 dark:to-gold-900/30 border-gold-200 dark:border-gold-800">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
                <User className="w-5 h-5 text-gray-900" />
              </div>
              <div>
                <p className="font-semibold text-gray-900 dark:text-white">{userEntry.full_name} (You)</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  Rank #{userEntry.rank} • {userEntry.total_points} pts
                </p>
              </div>
            </div>
            <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
              <div className="flex items-center gap-1">
                <Target className="w-4 h-4" />
                {userEntry.correct_winners}
              </div>
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4" />
                {userEntry.exact_scores}
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="card overflow-hidden">
        <div className="bg-gray-50 dark:bg-gray-800 px-4 py-3 border-b border-gray-200 dark:border-gray-700">
          <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-4 text-sm font-medium text-gray-600 dark:text-gray-400">
            <div className="w-12 text-center">#</div>
            <div>Player</div>
            <div className="text-right w-20">Points</div>
            <div className="text-center w-16 hidden sm:block">Winners</div>
            <div className="text-center w-16 hidden sm:block">Exact</div>
          </div>
        </div>
        {rest.length > 0 ? (
          <div className="divide-y divide-gray-100 dark:divide-gray-800 max-h-[50vh] overflow-y-auto scrollbar-thin">
            {rest.map((entry) => (
              <div
                key={entry.user_id}
                className={`px-4 py-3 grid grid-cols-[auto_1fr_auto_auto_auto] gap-4 items-center transition-colors ${
                  entry.user_id === user?.id
                    ? 'bg-gold-50 dark:bg-gold-900/20'
                    : 'hover:bg-gray-50 dark:hover:bg-gray-800/50'
                }`}
              >
                <div className="w-12 text-center font-medium text-gray-500 dark:text-gray-400">
                  {entry.rank}
                </div>
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-gray-400 to-gray-500 flex items-center justify-center shrink-0">
                    <User className="w-4 h-4 text-white" />
                  </div>
                  <span className="font-medium text-gray-900 dark:text-white truncate">
                    {entry.full_name}
                    {entry.user_id === user?.id && (
                      <span className="ml-2 text-xs text-gold-600 dark:text-gold-400">(You)</span>
                    )}
                  </span>
                </div>
                <div className="text-right w-20">
                  <span className="font-bold text-gray-900 dark:text-white">{entry.total_points}</span>
                </div>
                <div className="text-center w-16 hidden sm:block text-gray-600 dark:text-gray-400">
                  {entry.correct_winners}
                </div>
                <div className="text-center w-16 hidden sm:block text-gray-600 dark:text-gray-400">
                  {entry.exact_scores}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="p-8 text-center text-gray-500 dark:text-gray-400">
            <TrendingUp className="w-8 h-8 mx-auto mb-2 opacity-50" />
            Only {top3.length} player{top3.length !== 1 ? 's' : ''} so far
          </div>
        )}
      </div>
    </div>
  );
}
