import { useState, useEffect, useCallback } from 'react';
import { supabase, Match, Prediction } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { MatchCard } from './MatchCard';
import { AlertCircle, Trophy, Filter, Search, Calendar } from 'lucide-react';

type MatchFilter = 'all' | 'upcoming' | 'completed' | 'predicted';

export function MatchesPage() {
  const { user } = useAuth();
  const [matches, setMatches] = useState<Match[]>([]);
  const [predictions, setPredictions] = useState<Map<string, Prediction>>(new Map());
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<MatchFilter>('all');
  const [roundFilter, setRoundFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const fetchData = useCallback(async () => {
    if (!user) return;

    setLoading(true);
    const [matchesRes, predictionsRes] = await Promise.all([
      supabase
        .from('matches')
        .select('*, home_team:teams!matches_home_team_id_fkey(*, flag:flags(*)), away_team:teams!matches_away_team_id_fkey(*, flag:flags(*))')
        .order('kickoff_time', { ascending: true }),
      supabase
        .from('predictions')
        .select('*, match:matches(*, home_team:teams!matches_home_team_id_fkey(*, flag:flags(*)), away_team:teams!matches_away_team_id_fkey(*, flag:flags(*)))')
        .eq('user_id', user.id),
    ]);

    if (matchesRes.data) {
      setMatches(matchesRes.data);
    }

    if (predictionsRes.data) {
      const predMap = new Map<string, Prediction>();
      predictionsRes.data.forEach((pred) => {
        predMap.set(pred.match_id, pred);
      });
      setPredictions(predMap);
    }

    setLoading(false);
  }, [user]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  const handlePredict = async (matchId: string, homeScore: number, awayScore: number) => {
    if (!user) return;

    const { error } = await supabase.from('predictions').upsert(
      {
        user_id: user.id,
        match_id: matchId,
        predicted_home_score: homeScore,
        predicted_away_score: awayScore,
      },
      { onConflict: 'user_id,match_id' }
    );

    if (!error) {
      await fetchData();
    }
  };

  const rounds = [...new Set(matches.map((m) => m.round))];

  const now = new Date();
  const filteredMatches = matches.filter((match) => {
    const kickoff = new Date(match.kickoff_time);
    const isLocked = kickoff <= now;

    if (roundFilter !== 'all' && match.round !== roundFilter) return false;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      const homeName = match.home_team?.name?.toLowerCase() || '';
      const awayName = match.away_team?.name?.toLowerCase() || '';
      if (!homeName.includes(query) && !awayName.includes(query)) {
        return false;
      }
    }

    switch (filter) {
      case 'upcoming':
        return !isLocked;
      case 'completed':
        return match.is_completed;
      case 'predicted':
        return predictions.has(match.id);
      default:
        return true;
    }
  });

  const upcomingCount = matches.filter((m) => new Date(m.kickoff_time) > now).length;
  const completedCount = matches.filter((m) => m.is_completed).length;
  const predictedCount = predictions.size;

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[60vh]">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading matches...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
          Match Predictions
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          Predict outcomes and exact scores to earn points
        </p>
      </div>

      {/* Stats Cards */}
      {matches.length > 0 && (
        <div className="grid grid-cols-3 gap-4 mb-6">
          <div className="card p-4 text-center">
            <p className="text-2xl font-bold text-grass-600 dark:text-grass-400">{upcomingCount}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Upcoming</p>
          </div>
          <div className="card p-4 text-center">
            <p className="text-2xl font-bold text-gold-600 dark:text-gold-400">{predictedCount}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Predicted</p>
          </div>
          <div className="card p-4 text-center">
            <p className="text-2xl font-bold text-gray-600 dark:text-gray-400">{completedCount}</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Completed</p>
          </div>
        </div>
      )}

      {/* Filters */}
      {matches.length > 0 && (
        <div className="card mb-6">
          <div className="p-4 flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Search teams..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="input-field pl-10"
              />
            </div>
            <div className="flex gap-2">
              <div className="relative">
                <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                <select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value as MatchFilter)}
                  className="input-field pl-9 pr-8 appearance-none cursor-pointer"
                >
                  <option value="all">All Matches</option>
                  <option value="upcoming">Upcoming</option>
                  <option value="completed">Completed</option>
                  <option value="predicted">Predicted</option>
                </select>
              </div>
              {rounds.length > 1 && (
                <select
                  value={roundFilter}
                  onChange={(e) => setRoundFilter(e.target.value)}
                  className="input-field px-4 appearance-none cursor-pointer"
                >
                  <option value="all">All Rounds</option>
                  {rounds.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {matches.length === 0 ? (
        <div className="card p-12 text-center">
          <div className="w-20 h-20 rounded-full bg-gray-100 dark:bg-gray-700 flex items-center justify-center mx-auto mb-6">
            <Calendar className="w-10 h-10 text-gray-400" />
          </div>
          <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">
            No Matches Available
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-6 max-w-md mx-auto">
            Matches will appear here once the administrator adds them to the system.
            Check back soon!
          </p>
          <div className="flex items-center justify-center gap-2 text-sm text-gray-500 dark:text-gray-400">
            <Trophy className="w-4 h-4" />
            <span>Waiting for matches to be scheduled</span>
          </div>
        </div>
      ) : filteredMatches.length === 0 ? (
        <div className="card p-12 text-center">
          <AlertCircle className="w-12 h-12 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">No matches match your filters</p>
        </div>
      ) : (
        <div className="space-y-4">
          {filteredMatches.map((match) => (
            <MatchCard
              key={match.id}
              match={match}
              prediction={predictions.get(match.id)}
              onPredict={handlePredict}
              isLocked={new Date(match.kickoff_time) <= now}
            />
          ))}
        </div>
      )}
    </div>
  );
}
