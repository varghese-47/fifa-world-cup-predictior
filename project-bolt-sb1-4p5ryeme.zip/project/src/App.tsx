import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthPage } from './components/AuthPage';
import { Header } from './components/Header';
import { MatchesPage } from './components/MatchesPage';
import { LeaderboardPage } from './components/LeaderboardPage';
import { AdminPanel } from './components/AdminPanel';
import { Trophy, Users, Target } from 'lucide-react';

function AppContent() {
  const { user, loading } = useAuth();
  const [currentPage, setCurrentPage] = useState<'matches' | 'leaderboard' | 'admin'>('matches');

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-gold-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthPage />;
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
      <Header currentPage={currentPage} onNavigate={setCurrentPage} />

      <main className="flex-1">
        {currentPage === 'matches' && <MatchesPage />}
        {currentPage === 'leaderboard' && <LeaderboardPage />}
        {currentPage === 'admin' && <AdminPanel />}
      </main>

      <footer className="bg-white dark:bg-gray-800 border-t border-gray-200 dark:border-gray-700 py-8 mt-auto">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            <div className="text-center md:text-left">
              <div className="flex items-center gap-2 justify-center md:justify-start mb-3">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-400 to-gold-600 flex items-center justify-center">
                  <Trophy className="w-4 h-4 text-gray-900" />
                </div>
                <span className="font-bold text-gray-900 dark:text-white">WC Predictor</span>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Predict the future. Compete with the world.
              </p>
            </div>

            <div className="text-center">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center justify-center gap-2">
                <Target className="w-4 h-4" />
                Scoring System
              </h4>
              <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                <p>Correct Winner: <span className="font-semibold text-gold-600 dark:text-gold-400">1 Point</span></p>
                <p>Exact Score: <span className="font-semibold text-gold-600 dark:text-gold-400">+3 Points</span></p>
              </div>
            </div>

            <div className="text-center md:text-right">
              <h4 className="font-semibold text-gray-900 dark:text-white mb-3 flex items-center justify-center md:justify-end gap-2">
                <Users className="w-4 h-4" />
                FIFA World Cup 2026
              </h4>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                United States, Canada & Mexico
              </p>
            </div>
          </div>

          <div className="border-t border-gray-200 dark:border-gray-700 pt-6 text-center">
            <p className="text-sm text-gray-500 dark:text-gray-400">
              Made with passion for the beautiful game
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
