import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL as string;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY as string;

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export type Flag = {
  id: string;
  name: string;
  filename: string | null;
  file_type: string | null;
  file_size: number | null;
  storage_path: string | null;
  image_url: string;
  created_at: string;
  updated_at: string;
};

export type Team = {
  id: string;
  name: string;
  code: string;
  flag_url: string;
  flag_id: string | null;
  flag?: Flag;
};

export type Match = {
  id: string;
  home_team_id: string;
  away_team_id: string;
  kickoff_time: string;
  match_number: number;
  round: string;
  venue: string | null;
  home_score: number | null;
  away_score: number | null;
  is_completed: boolean;
  home_team: Team;
  away_team: Team;
};

export type Prediction = {
  id: string;
  user_id: string;
  match_id: string;
  predicted_home_score: number;
  predicted_away_score: number;
  points_awarded: number;
  winner_points_awarded: number;
  exact_score_awarded: boolean;
  match: Match;
};

export type Profile = {
  id: string;
  full_name: string;
  email: string;
  is_admin: boolean;
};

export type UserScore = {
  id: string;
  user_id: string;
  total_points: number;
  correct_winners: number;
  exact_scores: number;
  predictions_made: number;
  profile: Profile;
};

export type LeaderboardEntry = {
  user_id: string;
  full_name: string;
  total_points: number;
  correct_winners: number;
  exact_scores: number;
  rank: number;
};
